var searchData=
[
  ['micros',['micros',['../timer_8c.html#a61fd67e03b403ddf07454b7d920d8176',1,'micros(unsigned long *D):&#160;timer.c'],['../timer_8h.html#a11579a534eb2d98d27492f6e0697e589',1,'micros(unsigned long *X):&#160;timer.c']]],
  ['millis',['millis',['../timer_8c.html#a1f4540f13369eb401f59bff9529b7eb0',1,'millis(unsigned long *D):&#160;timer.c'],['../timer_8h.html#a1eab0f3d1e1b7648c57c2ebcad5d9b26',1,'millis(unsigned long *X):&#160;timer.c']]]
];
